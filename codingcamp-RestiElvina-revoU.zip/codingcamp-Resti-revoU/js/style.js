// Home Page: Fill name in welcome message
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('welcome')) {
        const userName = prompt('Enter your name:') || 'Guest';
        document.getElementById('welcome').textContent = `Hi, ${userName}!`;
    }

    // Contact Page: Form validation and submit display
    const form = document.getElementById('contactForm');
    const submitInfo = document.getElementById('submitInfo');

    if (form && submitInfo) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();

            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();

            // Validation
            if (!name) {
                alert('Name is required!');
                return;
            }
            if (!email) {
                alert('Email is required!');
                return;
            }
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email!');
                return;
            }
            if (!message) {
                alert('Message is required!');
                return;
            }

            // Display submitted values
            submitInfo.innerHTML = `
                <h3>Thank you! Your message has been submitted.</h3>
                <p><strong>Name:</strong> ${name}</p>
                <p><strong>Email:</strong> ${email}</p>
                <p><strong>Message:</strong> ${message}</p>
            `;
            submitInfo.style.display = 'block';

            // Reset form
            form.reset();
        });
    }
});
