document.addEventListener("DOMContentLoaded", function () {
  const clock = document.getElementById("clock");
  const dateDisplay = document.getElementById("date");

  setInterval(() => {
    let date = new Date();
    let clock = document.getElementById("clock");
    clock.innerHTML =
      date.getHours().toString().padStart(2, "0") +
      ":" +
      date.getMinutes().toString().padStart(2, "0") +
      ":" +
      date.getSeconds().toString().padStart(2, "0");
  }, 100);
});
